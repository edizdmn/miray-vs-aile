MIRAY VS AILE V6 - Çok Yavaş / Oynanabilir Sürüm

Değişiklikler:
- Başlangıç hızı V5'e göre yaklaşık %40 yavaşlatıldı.
- Genel oyun akışı V5'e göre yaklaşık %30 yavaşlatıldı.
- Engeller daha geç ve daha kontrollü geliyor.
- Ediz daha nadir geliyor.
- Bölüm hızlanması daha yumuşak.

GitHub'a yükleme:
1) ZIP'i çıkar.
2) İçindeki app klasörü, build.gradle ve settings.gradle dosyasını GitHub repo ana sayfasına yükle.
3) Commit changes de.
4) Actions yeşil tik olunca Artifacts > Miray-vs-Aile-APK indir.
